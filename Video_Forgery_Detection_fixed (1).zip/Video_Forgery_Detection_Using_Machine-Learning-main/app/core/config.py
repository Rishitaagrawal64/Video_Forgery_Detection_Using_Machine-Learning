from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    app_name: str = "AI Video Forgery Detection API"
    app_version: str = "0.1.0"

    upload_dir: Path = BASE_DIR / "data" / "uploads"
    frames_dir: Path = BASE_DIR / "data" / "frames"

    max_upload_mb: int = 200
    allowed_extensions: tuple[str, ...] = (".mp4", ".avi", ".mov", ".mkv", ".webm")

    # Frame extraction / preprocessing defaults
    num_frames: int = 16
    frame_size: int = 224
    normalize_mode: str = "unit"  # "unit" -> [0,1], "imagenet", "tanh" -> [-1,1]
    save_frames: bool = False
    detect_faces: bool = False

    # Which predictor to load (see app/models/registry.py)
    predictor: str = "heuristic"
    model_path: str | None = None
    hf_model_id: str = "umm-maybe/AI-image-detector"  # used when predictor == "hf"
    threshold: float = 0.5  # video-level forged probability cutoff
    check_provenance: bool = True  # scan file for C2PA / AI-generator metadata

    cors_origins: list[str] = ["http://localhost:3000", "http://localhost:5173"]

    model_config = SettingsConfigDict(env_prefix="FORGERY_", env_file=".env", extra="ignore")


settings = Settings()
settings.upload_dir.mkdir(parents=True, exist_ok=True)
settings.frames_dir.mkdir(parents=True, exist_ok=True)
