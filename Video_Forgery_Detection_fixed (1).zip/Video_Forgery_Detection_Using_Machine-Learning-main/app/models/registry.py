"""Predictor registry. Add the real CNN here when it is ready."""
from __future__ import annotations

from functools import lru_cache

import numpy as np

from app.core.config import settings
from app.models.base import BasePredictor
from app.models.heuristic import HeuristicPredictor


class KerasPredictor(BasePredictor):
    """Example adapter for a saved Keras model (.keras / .h5). Requires `pip install tensorflow`.

    Expects a model that maps (N, H, W, 3) -> (N, 1) or (N,) forged probabilities.
    """

    name = "keras-cnn"

    def __init__(self, model_path: str):
        import tensorflow as tf  # imported lazily so TF is optional

        self.model = tf.keras.models.load_model(model_path)

    def predict_frames(self, batch):
        return self.model.predict(batch, verbose=0).reshape(len(batch))


class HuggingFacePredictor(BasePredictor):
    """Pretrained image-classification detector from the Hugging Face Hub, run on each frame.

    Needs `pip install torch transformers pillow`. Pick the model with FORGERY_HF_MODEL_ID and
    use FORGERY_NORMALIZE_MODE=unit and a large FORGERY_FRAME_SIZE (e.g. 512) so generator
    artifacts are not blurred away by downscaling.
    """

    _FAKE_HINTS = ("artificial", "ai", "fake", "synthetic", "generated", "deepfake")

    def __init__(self, model_id: str):
        from transformers import pipeline

        self.name = f"hf:{model_id}"
        self.pipe = pipeline("image-classification", model=model_id, top_k=None)

    def predict_frames(self, batch):
        from PIL import Image

        imgs = [Image.fromarray((np.clip(x, 0, 1) * 255).astype(np.uint8)) for x in batch]
        out = []
        for res in self.pipe(imgs):
            score = max(
                (r["score"] for r in res if any(h in r["label"].lower().split("_") + r["label"].lower().split() for h in self._FAKE_HINTS)),
                default=0.0,
            )
            out.append(score)
        return np.array(out, dtype=np.float32)


def _build_hf() -> BasePredictor:
    return HuggingFacePredictor(settings.hf_model_id)


def _build_keras() -> BasePredictor:
    if not settings.model_path:
        raise RuntimeError("Set FORGERY_MODEL_PATH to use the keras predictor")
    return KerasPredictor(settings.model_path)


_FACTORIES = {
    "heuristic": HeuristicPredictor,
    "keras": _build_keras,
    "hf": _build_hf,
}


@lru_cache(maxsize=1)
def get_predictor() -> BasePredictor:
    try:
        return _FACTORIES[settings.predictor]()
    except KeyError:
        raise RuntimeError(f"Unknown predictor {settings.predictor!r}; options: {list(_FACTORIES)}")
