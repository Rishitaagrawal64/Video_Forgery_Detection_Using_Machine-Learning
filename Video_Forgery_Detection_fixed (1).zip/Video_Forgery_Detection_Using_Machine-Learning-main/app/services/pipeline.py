"""End-to-end pipeline: video -> frames -> preprocessed batch -> prediction."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from app.core.config import settings
from app.models.base import FORGED, BasePredictor, Prediction
from app.services import frame_extractor as fx
from app.services.preprocessing import preprocess_frames
from app.services.provenance import find_ai_markers


@dataclass
class PipelineResult:
    video: fx.VideoInfo
    num_frames: int
    prediction: Prediction
    saved_frames: list[str] = field(default_factory=list)


def run_pipeline(
    video_path: str | Path,
    predictor: BasePredictor,
    *,
    num_frames: int | None = None,
    size: int | None = None,
    mode: str | None = None,
    detect_faces: bool | None = None,
    save: bool | None = None,
    frames_out: str | Path | None = None,
) -> PipelineResult:
    info = fx.get_video_info(video_path)
    frames = fx.extract_uniform(video_path, num_frames or settings.num_frames)

    saved: list[str] = []
    if settings.save_frames if save is None else save:
        out = Path(frames_out) if frames_out else settings.frames_dir / Path(video_path).stem
        saved = [str(p) for p in fx.save_frames(frames, out)]

    batch = preprocess_frames(
        frames,
        size=size or settings.frame_size,
        mode=mode or settings.normalize_mode,
        detect_faces=settings.detect_faces if detect_faces is None else detect_faces,
    )
    prediction = predictor.predict(batch, threshold=settings.threshold)

    # Embedded AI-provenance metadata (C2PA / IPTC / Veo tags) overrides the frame classifier.
    markers = find_ai_markers(video_path) if settings.check_provenance else []
    if markers:
        prediction = Prediction(
            label=FORGED,
            forged_probability=max(prediction.forged_probability, 0.99),
            frame_scores=prediction.frame_scores,
            reasons=[f"Provenance metadata: {m}" for m in markers],
        )
    elif prediction.label == FORGED:
        prediction.reasons.append(f"Frame classifier ({predictor.name}) score >= {settings.threshold}")
    return PipelineResult(info, len(frames), prediction, saved)
