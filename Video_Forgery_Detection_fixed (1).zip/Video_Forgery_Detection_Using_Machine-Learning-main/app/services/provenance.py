"""Provenance check: look for AI-generation markers embedded in the video file itself.

Many generators (Google Veo / Gemini, Sora, Runway, ...) write C2PA "Content Credentials" or
IPTC `digitalSourceType = trainedAlgorithmicMedia` into the container. When present this is a far
stronger signal than anything a frame-level classifier can give. When absent it proves nothing:
re-encoding, screen recording or social-media upload strips the metadata.
"""
from __future__ import annotations

from pathlib import Path

# (needle, human-readable reason). Needles are matched case-sensitively on raw bytes.
_MARKERS: list[tuple[bytes, str]] = [
    (b"trainedAlgorithmicMedia", "IPTC digitalSourceType: trained algorithmic media (AI-generated)"),
    (b"compositeWithTrainedAlgorithmicMedia", "IPTC digitalSourceType: composite with AI media"),
    (b"c2pa.created", "C2PA manifest present"),
    (b"c2pa", "C2PA manifest present"),
    (b"jumbf", "JUMBF/C2PA content credentials present"),
    (b"SynthID", "SynthID marker in metadata"),
    (b"Made with Google AI", "Tagged 'Made with Google AI'"),
    (b"Google Veo", "Tagged as Google Veo"),
    (b"Veo 3", "Tagged as Google Veo 3"),
    (b"Veo 2", "Tagged as Google Veo 2"),
    (b"OpenAI Sora", "Tagged as OpenAI Sora"),
    (b"Runway", "Tagged as Runway"),
    (b"Kling", "Tagged as Kling"),
]

_CHUNK = 4 * 1024 * 1024
_OVERLAP = 64


def find_ai_markers(path: str | Path) -> list[str]:
    """Return de-duplicated reasons for every AI-generation marker found in the file bytes."""
    found: dict[str, None] = {}
    tail = b""
    with open(path, "rb") as f:
        while chunk := f.read(_CHUNK):
            buf = tail + chunk
            for needle, reason in _MARKERS:
                if needle in buf:
                    found.setdefault(reason, None)
            tail = buf[-_OVERLAP:]
    return list(found)
